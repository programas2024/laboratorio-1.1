import tkinter as tk

class Cambiar:
    def __init__(self, ventana, boton_cambiar_color):
        self.ventana = ventana
        self.boton_cambiar_color = boton_cambiar_color
        self.imagen_dom = tk.PhotoImage(file="imagenes\\dom.png")
        self.imagen_noche = tk.PhotoImage(file="imagenes\\noche.png")
        self.imagen_actual = self.imagen_noche
        self.cambiar_imagen = True

    def cambiar_imagen_boton(self):
        if self.cambiar_imagen:
            self.boton_cambiar_color.config(image=self.imagen_noche)
            self.cambiar_imagen = False
            self.ventana.configure(bg="white")  # Cambiar el color de fondo de la ventana
        else:
            self.boton_cambiar_color.config(image=self.imagen_dom)
            self.cambiar_imagen = True
            self.ventana.configure(bg="black")  # Cambiar el color de fondo de la ventana

   