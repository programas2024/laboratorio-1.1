
from similar import MusicPlayer

class Main():
    def main():
        
        app = MusicPlayer()
    main()
