import os
from tkinter import ttk
import random
import pygame
from tkinter import Tk, Button, Label, filedialog, Entry,Toplevel,Scrollbar,Frame,Canvas,END
import mysql.connector
from tkinter.ttk import Separator
from datetime import datetime
import tkinter as tk
from Cambiar import Cambiar
from ControlVolumen import ControlVolumen
from Bateria import Bateria
from Bluetooth import BluetoothManager
from pydub import AudioSegment
from pytube import YouTube
from tkinter import Menu, Menubutton, RAISED
from tkinter import messagebox
import pytube
import threading
from moviepy.editor import AudioFileClip
from moviepy.editor import VideoFileClip
class Aleatorio:

    def __init__(self, ventana):
        self.ventana = ventana
        self.ventana.title("Reproductor Aleatorio")
        self.ventana.geometry("950x600")
        self.ventana.configure(bg="white")
        
        self.ruta_carpeta = None
        self.lista_musica = []
        self.lista_reproduccion = []
        self.indice_actual = -1
        self.tiempo_pausa = None
        self.cancion_seleccionada = None  # Variable para almacenar la canción seleccionada
      
        # Crear instancia de la clase ControlVolumen
        self.control_volumen = ControlVolumen(self.ventana, pygame.mixer)

        # Colores disponibles: blanco, negro y verde
        colores_disponibles = ["white", "black"]

        self.bateria = Bateria(ventana)

         # Instancia de la clase BluetoothManager
        self.manager = BluetoothManager()

        self.modo_automatico = tk.BooleanVar(value=False)

        self.imagen_music = tk.PhotoImage(file="imagenes\\musica.png")
        self.imagen_adelante = tk.PhotoImage(file="imagenes\\adelante.png")
        self.imagen_buscar = tk.PhotoImage(file="imagenes\\buscar.png")
        self.imagen_detener = tk.PhotoImage(file="imagenes\\detener.png")
        self.imagen_actual = tk.PhotoImage(file="imagenes\\noche.png")
        self.imagen_dom = tk.PhotoImage(file="imagenes\\dom.png")


        self.imagen_play= tk.PhotoImage(file="imagenes\\play.png")
        self.imagen_reanudar = tk.PhotoImage(file="imagenes\\reanudar.png")
        self.imagen_repetir = tk.PhotoImage(file="imagenes\\repetir.png")
        self.imagen_vinilo= tk.PhotoImage(file="imagenes\\vinilo.png")
        self.imagen_x = tk.PhotoImage(file="imagenes\\x.png")
        self.imagen_lista = tk.PhotoImage(file="imagenes\\agregar lista.png")
        self.imagen_carpeta = tk.PhotoImage(file="imagenes\\multimedia.png")
        self.imagen_atras = tk.PhotoImage(file="imagenes\\atras.png")
        self.imagen_noche = tk.PhotoImage(file="imagenes\\noche.png")
        self.imagen_dom = tk.PhotoImage(file="imagenes\\dom.png")

        self.imagen_aumneto = tk.PhotoImage(file="imagenes\\aumenta-el-volumen.png")
        self.imagen_bajar = tk.PhotoImage(file="imagenes\\reducir-volumen.png")
        self.imagen_blue = tk.PhotoImage(file="imagenes\\bluetooth.png")

       
        
        self.label_imagen = Label(ventana, text="REPRODUCTOR MUSICAL.",image=self.imagen_music, bg="white")
        self.label_imagen.place(x=300, y=200,anchor="center") 



        self.label_cancion_actual = Label(ventana, text="", bg="white")
        self.label_cancion_actual.place(x=800, y=160, anchor="center")
        
        self.label_estado2 = Label(ventana, text="REPRODUCTOR MUSICAL.", bg="white",image=self.imagen_aumneto)
        self.label_estado2.place(x=745, y=280, anchor="center")

        self.label_estado3 = Label(ventana, text="REPRODUCTOR MUSICAL.", bg="white",image=self.imagen_bajar)
        self.label_estado3.place(x=745, y=130, anchor="center")

        self.label_estado4 = Label(ventana, text="Volumen", bg="white")
        self.label_estado4.place(x=745, y=100, anchor="center")


        

        self.label_estado = Label(ventana, text="REPRODUCTOR MUSICAL.", bg="white")
        self.label_estado.place(x=300, y=150, anchor="center")

        self.boton_seleccionar_carpeta = Button(ventana, text=" Carpeta",image=self.imagen_carpeta, background="white",borderwidth=0,command=self.seleccionar_carpeta)
        self.boton_seleccionar_carpeta.place(x=50, y=50, anchor="center")

        self.boton_aleatorio = Button(ventana, text="v. a escuchar",image=self.imagen_atras, background="white",borderwidth=0, command=self.reproducir_aleatorio)
        self.boton_aleatorio.place(x=320, y=50, anchor="center")

        self.boton_buscar = Button(ventana, text="Buscar",image=self.imagen_buscar, background="white",borderwidth=0, command=self.reproducir_cancion_seleccionada)
        self.boton_buscar.place(x=720, y=50, anchor="center")

        self.boton_detener = Button(ventana, text="Detener",image=self.imagen_detener, background="white",borderwidth=0, command=self.pausar_reproduccion)
        self.boton_detener.place(x=110, y=110, anchor="center")

        self.boton_pasar = Button(ventana, text="Pasar",image=self.imagen_adelante, background="white",borderwidth=0, command=self.reproducir_siguiente_aleatorio)
        self.boton_pasar.place(x=310, y=110, anchor="center")

        self.boton_escuchar = Button(ventana, text="Escuchar",image=self.imagen_play, background="white",borderwidth=0, command=self.escuchar_cancion)
        self.boton_escuchar.place(x=180, y=110, anchor="center")

        self.boton_repetir = Button(ventana, text="Repetir",image=self.imagen_repetir, background="white",borderwidth=0, command=self.repetir_cancion)
        self.boton_repetir.place(x=50, y=110, anchor="center")


        self.boton_limpiar_campo = Button(ventana, text="Limpiar ",image=self.imagen_x, background="white",borderwidth=0, command=self.limpiar_campo)
        self.boton_limpiar_campo.place(x=670, y=50, anchor="center")

        self.boton_anadir = Button(ventana, text="Añadir",image=self.imagen_lista, background="white",borderwidth=0, command=self.anadir_a_base_de_datos, state="disabled")
        self.boton_anadir.place(x=120, y=50, anchor="center")

        self.boton_reanudar = Button(ventana, text="Reanudar",image=self.imagen_reanudar, background="white",borderwidth=0, command=self.reanudar_reproduccion)
        self.boton_reanudar.place(x=250, y=110, anchor="center")

        self.boton_reproduccion_continua = Button(ventana, text="Reproducción Continua", background="white",borderwidth=0,image=self.imagen_vinilo, command=self.reproducir_continuamente)
        self.boton_reproduccion_continua.place(x=260, y=50, anchor="center")


         # Crear primero el botón
        self.boton_cambiar_color = tk.Button(ventana, text="Cambiar color",image=self.imagen_noche, background="white",borderwidth=0)
        self.boton_cambiar_color.place(x=200, y=50, anchor="center")

        # Luego, crear el objeto GestorImagenes y pasar el botón como argumento
        self.gestor_imagenes = Cambiar(self.ventana, self.boton_cambiar_color)

        # Configurar el comando del botón después de crear el objeto GestorImagenes
        self.boton_cambiar_color.config(command=self.gestor_imagenes.cambiar_imagen_boton)

        self.boton_bluetooth = Button(ventana, text="Bluetooth",image=self.imagen_blue, background="white",borderwidth=0, command=self.conectar_bluetooth)
        self.boton_bluetooth.place(x=770, y=50, anchor="center")


    # Crear una caja de entrada de texto para pegar el enlace de la canción
        self.caja_enlace = Entry(ventana, width=40)
        self.caja_enlace.insert(0, "Pegar enlace de YouTube aquí")
        self.caja_enlace.bind("<FocusIn>", self.on_entry_click_enlace)
        self.caja_enlace.bind("<FocusOut>", self.on_focus_out_enlace)
        self.caja_enlace.place(x=400, y=300, anchor="center")

        # Crear menú contextual para la caja de enlace
        self.menu_contextual_enlace = Menu(ventana, tearoff=0)
        self.menu_contextual_enlace.add_command(label="Pegar", command=self.pegar_enlace)

        def mostrar_menu_enlace(event):
            self.menu_contextual_enlace.post(event.x_root, event.y_root)

        self.caja_enlace.bind("<Button-3>", mostrar_menu_enlace)




        # Botón para desplegar opciones de descarga
        self.boton_descargar = Menubutton(ventana, text="Descargar", relief=RAISED)
        self.boton_descargar.menu = Menu(self.boton_descargar, tearoff=0)
        self.boton_descargar["menu"] = self.boton_descargar.menu
        self.boton_descargar.menu.add_command(label="MP3", command=self.descargar_mp3,state="disabled")
        self.boton_descargar.menu.add_command(label="MP4", command=self.descargar_mp4)
        self.boton_descargar.place(x=400, y=350, anchor="center")


        
    
        self.caja_busqueda = Entry(ventana, width=30)
        self.caja_busqueda.insert(0, "Buscar música")
        self.caja_busqueda.bind("<FocusIn>", self.on_entry_click)
        self.caja_busqueda.bind("<FocusOut>", self.on_focus_out)
        self.caja_busqueda.bind("<KeyRelease>", self.autocompletar)
        self.caja_busqueda.place(x=550, y=50, anchor="center")

        # Línea separadora
        self.separador1 = Separator(ventana, orient="horizontal")
        self.separador1.place(x=5, y=85, relwidth=1)

        self.separador2 = Separator(ventana, orient="horizontal")
        self.separador2.place(x=5, y=15, relwidth=1)

        self.separador3 = Separator(ventana, orient="horizontal")
        self.separador3.place(x=5, y=130, relwidth=0.5)

        self.cancion_actual = None
        self.barra_progreso = ttk.Progressbar(ventana, orient="horizontal", mode="determinate")
        self.barra_progreso.place(x=50, y=250, width=850)

        self.ventana.after(100, self.actualizar_barra_progreso) 


        # Inicializar pygame
        pygame.init()

        
        self.conexion_base_datos()


    def pegar_enlace(self):
        contenido = self.ventana.clipboard_get()
        self.caja_enlace.insert("insert", contenido)


    def descargar_mp3(self):
        pass  # Aquí deberías implementar la descarga y conversión a MP3

    def descargar_mp4(self):
        self.ventana_resolucion = Toplevel(self.ventana)
        self.ventana_resolucion.geometry("300x200")
        self.ventana_resolucion.title("Seleccione resolución")

        Label(self.ventana_resolucion, text="Seleccione la resolución del video MP4:").pack()

        # Botones de resolución
        Button(self.ventana_resolucion, text="720p", command=lambda: self.descargar_mp4_con_resolucion("720p")).pack()
        Button(self.ventana_resolucion, text="480p", command=lambda: self.descargar_mp4_con_resolucion("480p")).pack()
        Button(self.ventana_resolucion, text="360p", command=lambda: self.descargar_mp4_con_resolucion("360p")).pack()

    def descargar_mp4_con_resolucion(self, resolucion):
        enlace = self.caja_enlace.get()
        if enlace:
            self.descargar_desde_youtube(enlace, formato="mp4", resolucion=resolucion)
        else:
            messagebox.showwarning("Advertencia", "Por favor, pegue un enlace de YouTube primero.")
        self.ventana_resolucion.destroy()

    def descargar_desde_youtube(self, enlace, formato="mp3", resolucion=None):
        try:
            video = pytube.YouTube(enlace)
            streams = video.streams
            if formato == "mp4":
                if resolucion:
                    video_stream = streams.filter(res=resolucion, file_extension='mp4').first()
                else:
                    video_stream = streams.filter(file_extension='mp4').first()
                video_thread = threading.Thread(target=self.descargar_video, args=(video_stream,))
                video_thread.start()
            else:
                messagebox.showwarning("Advertencia", "Formato de archivo no válido.")
        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un error al descargar el video: {str(e)}")

    def descargar_video(self, video_stream):
        try:
            video_path = "c:\\Users\\joaco\\Desktop\\musica\\clases"
            video_stream.download(video_path)
            video_clip = VideoFileClip(video_path)
            audio_clip = video_clip.audio
            audio_path = "c:\\Users\\joaco\\Desktop\\musica\\clases"
            audio_clip.write_audiofile(audio_path, fps=44100)  # Guardar el audio como WAV
            video_clip.close()
            messagebox.showinfo("Descarga completa", "El archivo de video se ha descargado y se ha creado el archivo de audio correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un error al descargar el video: {str(e)}")

    def on_entry_click_enlace(self, event):
        if self.caja_enlace.get() == "Pegar enlace de YouTube aquí":
            self.caja_enlace.delete(0, END)

    def on_focus_out_enlace(self, event):
        if self.caja_enlace.get() == "":
            self.caja_enlace.insert(0, "Pegar enlace de YouTube aquí")


    def descargar_audio(self, audio_stream):
        try:
            # Descargar el archivo de audio
            audio_path = os.path.join("c:\\Users\\joaco\\Desktop\\musica\\clases", audio_stream.default_filename)
            audio_stream.download(audio_path)
            
            # Convertir el archivo de audio a WAV
            wav_path = os.path.splitext(audio_path)[0] + ".wav"
            audioclip = AudioFileClip(audio_path)
            audioclip.write_audiofile(wav_path)
            
            # Reproducir el archivo de audio WAV
            pygame.mixer.init()
            pygame.mixer.music.load(wav_path)
            pygame.mixer.music.play()

            messagebox.showinfo("Descarga completa", "El archivo de audio se ha descargado correctamente y se está reproduciendo.")
        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un error al descargar y reproducir el audio: {str(e)}")
        
            


    def conexion_base_datos(self):
        try:
            # Establecer conexión a la base de datos
            self.connection = mysql.connector.connect(
                host="monorail.proxy.rlwy.net",
                user="root",
                port="45375",
                password="sYchLQHnJOAoyYhYcddALItnOPyInqpd",
                database="railway"
            )
            self.cursor = self.connection.cursor()
            # Crear tabla si no existe
            self.crear_tabla_si_no_existe()
        except mysql.connector.Error as err:
            print(f"Error al conectar a la base de datos: {err}")

    def crear_tabla_si_no_existe(self):
        try:
            # Verificar si la tabla existe en la base de datos
            self.cursor.execute("SHOW TABLES LIKE 'sonidos'")
            tabla_existe = self.cursor.fetchone()
            if not tabla_existe:
                # Crear la tabla si no existe
                self.cursor.execute("CREATE TABLE sonidos (id INT AUTO_INCREMENT PRIMARY KEY, cancion VARCHAR(255), compositor VARCHAR(255), duracion TIME, ruta VARCHAR(255), fecha_subida DATETIME)")
        except mysql.connector.Error as err:
            print(f"Error al crear la tabla en la base de datos: {err}")

    def escuchar_cancion(self):
        try:
            if not self.connection.is_connected():
                self.conexion_base_datos()  # Reconnect if connection is lost
            
            # Seleccionar una canción aleatoria de la base de datos
            self.cursor.execute("SELECT cancion FROM sonidos ORDER BY RAND() LIMIT 1")
            resultado = self.cursor.fetchone()
            
            if resultado:
                archivo_seleccionado = resultado[0]
                self.label_estado.config(text=f"Reproduciendo: {os.path.basename(archivo_seleccionado)}")

                # Cargar la canción desde la base de datos
                pygame.mixer.music.load(archivo_seleccionado)
                pygame.mixer.music.play()
                
                # Obtener la duración total de la canción
                duracion_total = pygame.mixer.Sound(archivo_seleccionado).get_length() / 1000  # Convertir a segundos
                
                # Iniciar la actualización de la barra de progreso
                self.actualizar_barra_progreso(duracion_total)
                
                # Loop de reproducción hasta que la canción termine
                while pygame.mixer.music.get_busy():
                    pygame.time.wait(100)  # Pequeña pausa para evitar un loop demasiado rápido
                    tiempo_reproducido = pygame.mixer.music.get_pos() / 1000  # Convertir a segundos
                    
                    # Actualizar la barra de progreso
                    self.actualizar_barra_progreso(tiempo_reproducido)
            else:
                self.label_estado.config(text="No hay canciones en la base de datos.")
        except mysql.connector.Error as err:
            print(f"Error al ejecutar la consulta SQL: {err}")
    

    def actualizar_barra_progreso(self):
        if self.cancion_actual is not None:
            # Obtener la duración total de la canción
            duracion_total = self.cancion_actual.get_length() / 1000  # Convertir a segundos
            
            # Actualizar la barra de progreso mientras se reproduce la canción
            while pygame.mixer.get_busy():
                pygame.time.wait(100)  # Pequeña pausa para evitar un loop demasiado rápido
                tiempo_reproducido = pygame.mixer.get_pos(self.cancion_actual) / 1000  # Convertir a segundos
                
                # Calcular el progreso actual y actualizar la barra de progreso en la interfaz de usuario
                progreso = (tiempo_reproducido / duracion_total) * 100
                # Actualizar la barra de progreso en la interfaz de usuario
        else:
            print("Error: La canción actual no ha sido cargada correctamente.")

            
    def conectar_bluetooth(self):
        # Abrir el panel de configuración de Bluetooth
        self.manager.abrir_panel_bluetooth()

        # Dirección MAC del dispositivo Bluetooth al que deseamos conectarnos
        direccion_mac_dispositivo = "60-18-95-14-C5-F2"  # Reemplaza con la dirección MAC de tu dispositivo

        # Conectar el dispositivo Bluetooth
        self.manager.conectar_dispositivo(direccion_mac_dispositivo)

    def reproducir_continuamente(self):
        # Creamos el cursor aquí antes de ejecutar la consulta
        self.cursor = self.connection.cursor()
        self.cursor.execute("SELECT cancion FROM sonidos ORDER BY RAND()")
        resultados = self.cursor.fetchall()

        if resultados:
            # Limitar la cantidad de canciones a reproducir
            num_canciones_a_reproducir = min(200, len(resultados))
            for i in range(num_canciones_a_reproducir):
                cancion = resultados[i]
                archivo_cancion = cancion[0]
                nombre_cancion = os.path.basename(archivo_cancion)
                self.label_estado.config(text=f"Reproduciendo: {nombre_cancion}")

                pygame.mixer.music.load(archivo_cancion)
                pygame.mixer.music.play()

                # Actualizar el label de la canción actual
                self.label_cancion_actual.config(text=f"Canción actual: {nombre_cancion}")

                while pygame.mixer.music.get_busy():
                    pygame.time.Clock().tick(10)  # Esperar un poco antes de verificar si la canción terminó
        else:
            self.label_estado.config(text="No hay canciones en la base de datos.")


    def reanudar_reproduccion(self):
        if self.tiempo_pausa is not None:
            pygame.mixer.music.unpause()
            pygame.mixer.music.play(start=self.tiempo_pausa)  # Reanudar la reproducción desde el tiempo de pausa
            self.label_estado.config(text="Reproducción reanudada.")
            self.tiempo_pausa = None  # Restablecer la variable de tiempo de pausa
        else:
            self.label_estado.config(text="La reproducción no está pausada.")

    def anadir_a_base_de_datos(self):
        if self.ruta_carpeta:
            canciones_insertadas = 0
            # Establecer la conexión con la base de datos fuera del bucle for
            connection = mysql.connector.connect(
               host="monorail.proxy.rlwy.net",
                    user="root",
                    port="45375",
                    password="sYchLQHnJOAoyYhYcddALItnOPyInqpd",
                    database="railway",
            )

            # Crear el cursor
            cursor = connection.cursor()

            for archivo in self.lista_musica:
                # Verificar si la canción ya está en la base de datos
                cursor.execute("SELECT * FROM sonidos WHERE cancion = %s", (archivo,))
                resultado = cursor.fetchone()
                if not resultado:
                    # Insertar la canción en la base de datos
                    self.guardar_en_base_de_datos(cursor, archivo)
                    canciones_insertadas += 1

            # Confirmar los cambios en la base de datos y cerrar el cursor y la conexión
            connection.commit()
            cursor.close()
            connection.close()

            self.label_estado.config(text=f"{canciones_insertadas} canciones añadidas a la base de datos.")

    

    def repetir_cancion(self):
        # Reproducir la canción actualmente en reproducción nuevamente
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.rewind()


    def limpiar_campo(self):
        self.caja_busqueda.delete(0, 'end')
        self.ventana.focus_set()

    def autocompletar(self, event):
        texto_busqueda = self.caja_busqueda.get()
        if len(texto_busqueda) >= 4:
            sql = "SELECT cancion FROM sonidos WHERE cancion LIKE %s"
            val = ("%" + texto_busqueda + "%",)
            self.cursor.execute(sql, val)
            resultados = self.cursor.fetchall()
            if resultados:
                nombres_canciones = [os.path.basename(result[0]) for result in resultados]  # Obtener solo el nombre de la canción
                self.caja_busqueda.delete(0, "end")
                self.caja_busqueda.insert(0, nombres_canciones[0])  # Autocompletar con el primer resultado
                self.caja_busqueda.config(state="normal")  # Configurar la caja de búsqueda como solo lectura
                self.boton_buscar.focus()  # Dar el foco al botón de búsqueda

    def limpiar_caja_busqueda(self):
        self.caja_busqueda.delete(0, "end")
        self.caja_busqueda.config(state="normal")  # Restaurar la caja de búsqueda a su estado normal


    def escuchar_cancion(self):
        try:
            # Seleccionar una canción aleatoria de la base de datos
            self.cursor.execute("SELECT cancion FROM sonidos ORDER BY RAND() LIMIT 1")
            resultado = self.cursor.fetchone()
            
            if resultado:
                archivo_seleccionado = resultado[0]
                self.label_estado.config(text=f"Reproduciendo: {os.path.basename(archivo_seleccionado)}")

                pygame.mixer.music.load(archivo_seleccionado)  # Cargar la canción desde la base de datos
                pygame.mixer.music.play()
            else:
                self.label_estado.config(text="No hay canciones en la base de datos.")
        except mysql.connector.Error as err:
            print(f"Error al ejecutar la consulta SQL: {err}")


    def on_entry_click(self, event):
        if self.caja_busqueda.get() == "Buscar música":
            self.caja_busqueda.delete(0, "end")
            self.caja_busqueda.config(fg="black")

    def on_focus_out(self, event):
        if self.caja_busqueda.get() == "":
            self.caja_busqueda.insert(0, "Buscar música")
            self.caja_busqueda.config(fg="grey")

    def seleccionar_carpeta(self):
        self.ruta_carpeta = filedialog.askdirectory()
        if self.ruta_carpeta:
            self.lista_musica = [os.path.join(self.ruta_carpeta, archivo) for archivo in os.listdir(self.ruta_carpeta) if archivo.endswith('.mp3')]
            if self.lista_musica:
                self.label_estado.config(text="Carpeta seleccionada con éxito.")
                self.boton_aleatorio.config(state="normal")
                self.boton_anadir.config(state="normal")  # Habilitar el botón "Añadir" cuando se selecciona la carpeta
            else:
                self.label_estado.config(text="La carpeta no contiene archivos de música.")
                self.boton_aleatorio.config(state="disabled")
                self.boton_anadir.config(state="disabled")  # Deshabilitar el botón "Añadir" si no hay canciones en la carpeta
        else:
            self.label_estado.config(text="No se ha seleccionado ninguna carpeta.")
            self.boton_aleatorio.config(state="disabled")
            self.boton_anadir.config(state="disabled")  # Deshabilitar el botón "Añadir" si no se selecciona ninguna carpeta


    def reproducir_aleatorio(self):
        if self.lista_reproduccion:  # Si hay canciones en la lista de reproducción
            if self.indice_actual == -1:  # Si es la primera reproducción
                self.indice_actual = 0  # Establecemos el índice actual al principio de la lista
            cancion_actual = self.lista_reproduccion[self.indice_actual]  # Obtenemos la canción actual
            self.label_estado.config(text=f"Reproduciendo: {os.path.basename(cancion_actual)}")
            pygame.mixer.music.load(cancion_actual)  # Cargamos la canción
            pygame.mixer.music.play()  # La reproducimos
        else:
            self.label_estado.config(text="No hay canciones en la lista de reproducción.")
        
    def reproducir_siguiente_aleatorio(self):
        # Seleccionar una canción aleatoria de la base de datos
        self.cursor.execute("SELECT cancion FROM sonidos ORDER BY RAND()")
        resultados = self.cursor.fetchall()
        
        if resultados:
            # Obtener una canción aleatoria de los resultados
            cancion_aleatoria = random.choice(resultados)[0]
            self.label_estado.config(text=f"Reproduciendo: {os.path.basename(cancion_aleatoria)}")

            pygame.mixer.music.load(cancion_aleatoria)
            pygame.mixer.music.play()
        else:
            self.label_estado.config(text="No hay canciones en la base de datos.")

    def pausar_reproduccion(self):
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.pause()
            self.tiempo_pausa = pygame.mixer.music.get_pos() / 1000  # Obtener el tiempo de reproducción en segundos
            self.label_estado.config(text="Reproducción pausada.")
        else:
            self.label_estado.config(text="No hay ninguna canción reproduciéndose.")

    def reproducir_cancion_seleccionada(self):
        nombre_cancion = self.caja_busqueda.get()
        if nombre_cancion:
            sql = "SELECT cancion FROM sonidos WHERE cancion LIKE %s"
            val = ("%" + nombre_cancion + "%",)
            self.cursor.execute(sql, val)
            resultados = self.cursor.fetchall()
            if resultados:
                # Obtener la primera canción que coincida con la búsqueda
                cancion_seleccionada = resultados[0][0]
                self.label_estado.config(text=f"Reproduciendo: {os.path.basename(cancion_seleccionada)}")

                pygame.mixer.music.load(cancion_seleccionada)
                pygame.mixer.music.play()
                self.caja_busqueda.delete(0, "end")  # Limpiar la caja de búsqueda después de reproducir la canción
            else:
                self.label_estado.config(text="No se encontraron canciones que coincidan con la búsqueda.")
        else:
            self.label_estado.config(text="La caja de búsqueda está vacía. Introduce el nombre de una canción.")


    def guardar_en_base_de_datos(self, cursor, archivo):
        fecha_subida = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sql = "INSERT INTO sonidos (cancion, fecha_subida) VALUES (%s, %s)"
        val = (archivo, fecha_subida)
        cursor.execute(sql, val)
        self.label_estado.config(text=f"Canción añadida a la base de datos: {os.path.basename(archivo)}")

    def crear_tabla_si_no_existe(self):
        # Verificar si la tabla Talentos existe en la base de datos
        self.cursor.execute("SHOW TABLES LIKE 'sonidos'")
        tabla_existe = self.cursor.fetchone()
        if not tabla_existe:
            # Crear la tabla Talentos si no existe
            self.cursor.execute("CREATE TABLE sonidos (id INT AUTO_INCREMENT PRIMARY KEY, cancion VARCHAR(255), compositor VARCHAR(255), duracion TIME, ruta VARCHAR(255), fecha_subida DATETIME)")

        self.boton_lista = Button(ventana, text="Lista", background="white", borderwidth=0, command=self.mostrar_lista)
        self.boton_lista.place(x=200, y=400, anchor="center")

    def cambiar_color_boton(self,boton):
        boton.config(bg="gray")

    def on_mousewheel(self,event):
        self.canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    def mostrar_lista(self):
        ventana_lista = Toplevel(self.ventana)
        ventana_lista.title("Lista de Canciones")
        ventana_lista.geometry("400x400")
        ventana_lista.configure(bg="white")
        
        # Crear un Canvas para contener los botones de canciones
        self.canvas = Canvas(ventana_lista)
        self.canvas.pack(side="left", fill="both", expand=True)

        # Configurar el enlace del mouse para desplazamiento con la rueda
        self.canvas.bind_all("<MouseWheel>", self.on_mousewheel)

        # Crear un Frame dentro del Canvas
        frame_canciones = Frame(self.canvas)
        self.canvas.create_window((0, 0), window=frame_canciones, anchor="nw")

        # Obtener canciones de la base de datos
        canciones = self.obtener_canciones_de_base_datos()

        # Crear botones para cada canción
        for i, cancion in enumerate(canciones):
            nombre_cancion = os.path.basename(cancion)
            boton_cancion = Button(frame_canciones, text=nombre_cancion, command=lambda ruta_cancion=cancion: self.reproducir_cancion(ruta_cancion), background="white")
            boton_cancion.bind("<Button-1>", lambda event, boton=boton_cancion: self.cambiar_color_boton(boton))
            boton_cancion.pack(fill="x")

    def obtener_canciones_de_base_datos(self):
        try:
            # Establecer conexión a la base de datos
            connection = mysql.connector.connect(
                host="monorail.proxy.rlwy.net",
                user="root",
                port="45375",
                password="sYchLQHnJOAoyYhYcddALItnOPyInqpd",
                database="railway"
            )
            cursor = connection.cursor()
            cursor.execute("SELECT cancion FROM sonidos")
            canciones = [fila[0] for fila in cursor.fetchall()]
            cursor.close()
            connection.close()
            return canciones
        except mysql.connector.Error as err:
            print(f"Error al obtener canciones de la base de datos: {err}")
            return []

    def reproducir_cancion(self, ruta_cancion):
        try:
            self.label_estado.config(text=f"Reproduciendo: {os.path.basename(ruta_cancion)}")
            pygame.mixer.music.load(ruta_cancion)
            pygame.mixer.music.play()
        except Exception as e:
            print(f"Error al reproducir la canción: {e}")

    def modificar_armonia_con_db(self, semitonos):
        try:
            if self.lista_reproduccion:
                for ruta_cancion in self.lista_reproduccion:
                    # Cargar la canción usando pydub
                    cancion = AudioSegment.from_file(ruta_cancion)

                    # Ajustar la armonía de la canción
                    cancion_modificada = cancion + semitonos  # Ajustar la armonía en semitonos

                    # Sobrescribir el archivo original con la canción modificada
                    cancion_modificada.export(ruta_cancion, format='mp3')
        except Exception as e:
            print(f"Error al modificar la armonía: {e}")

ventana = Tk()
app = Aleatorio(ventana)
ventana.mainloop()


