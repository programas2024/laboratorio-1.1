import os
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import filedialog, Menu, Menubutton, RAISED
import pygame.mixer
from similavolumen import similarvolumen
from tkinter import Button
from Bluetooth import BluetoothManager
from Bateria import Bateria
from similarCompartir import Compartir
from similarAyuda import similarayuida
from similarVersion import similarversion
from Similartooltip import SimilarTooltip
from similarAtajos import SimilarAtajos
from similarLista import SimilarLista
from similarBusqueda import SimilarBusqueda
from similarMusica import SimilarMusica
from similarFavorita import VentanaCrearCarpeta
from tkinter.simpledialog import askstring
from tkinter import messagebox

class MusicPlayer():

        
    def __init__(self):
        self.master = Tk()
        self.master.title("Reproductor de Música")
        self.master.geometry("1200x700")
      
        self.imagen4= tk.PhotoImage(file="imagenes/blanco.png")


        # Agregar un lienzo blanco que cubra toda la interfaz
        self.canvas = tk.Canvas(self.master, bg="white", width=1200, height=700)
        self.canvas.pack()

        self.label_song = tk.Label(self.master,image=self.imagen4, bg="white", fg="black")
        self.label_song.place(x=765, y=20)

        self.label_song = tk.Label(self.master,image=self.imagen4, bg="white", fg="black")
        self.label_song.place(x=-80, y=560)

        self.label_song1 = tk.Label(self.master,text="Opciones para escuchar", bg="white", fg="black")
        self.label_song1.place(x=800, y=150)

        self.label_song1 = tk.Label(self.master,text="Opciones para escuchar", bg="white", fg="black")
        self.label_song1.place(x=800, y=150)

        self.separator_black = tk.Canvas(self.master, width=3, height=700, bg="black", highlightthickness=0)
        self.separator_black.place(x=762, y=0)

        self.separator_horizontal = tk.Canvas(self.master, width=1200, height=3, bg="black", highlightthickness=0)
        self.separator_horizontal.place(x=10, y=20)

        self.separator_horizontal2 = tk.Canvas(self.master, width=1200, height=3, bg="black", highlightthickness=0)
        self.separator_horizontal2.place(x=10, y=80)

        self.previous_pos = 0
        self.playback_position = 0  # Almacena la posición de reproducción actual
        self.current_index = 0

        self.compartir = Compartir()
        self.control_volumen = similarvolumen(self.master, pygame.mixer)

        # Instancia de la clase BluetoothManager
        self.manager = BluetoothManager()

        self.similar_atajos = SimilarAtajos(self.master)

        self.bateria = Bateria(self.master)
        pygame.mixer.init()
        pygame.mixer.music.set_endevent(pygame.USEREVENT)  # Establecer evento de finalización de canción
        
        # Cargar la imagen y asignarla al atributo imagen
        self.imagen = tk.PhotoImage(file="imagenes/whatsapp.png")
        self.imagen2 = tk.PhotoImage(file="imagenes/compartir.png")
        self.imagen3= tk.PhotoImage(file="imagenes/fondo1.png")
        self.imagen5= tk.PhotoImage(file="imagenes/bluetooth (1).png")
        self.imagen6= tk.PhotoImage(file="imagenes/ajustes.png")
        self.imagen7= tk.PhotoImage(file="imagenes/pregunta.png")
        self.imagen8= tk.PhotoImage(file="imagenes/version.png")
        self.imagen9= tk.PhotoImage(file="imagenes/buscar.png")
        self.imagen10= tk.PhotoImage(file="imagenes/lista-de-reproduccion.png")
        self.imagen11= tk.PhotoImage(file="imagenes/multimedia (1).png")
        self.imagen12= tk.PhotoImage(file="imagenes/sol.png")
        self.imagen13= tk.PhotoImage(file="imagenes/luna.png")
        self.imagen14= tk.PhotoImage(file="imagenes/adelante2.png")
        self.imagen15= tk.PhotoImage(file="imagenes/adelantex2.png")
        self.imagen16= tk.PhotoImage(file="imagenes/detener (1).png")
        self.imagen17= tk.PhotoImage(file="imagenes/hacia-atras (1).png")
        self.imagen18= tk.PhotoImage(file="imagenes/hacia-atrasx2.png")
        self.imagen19= tk.PhotoImage(file="imagenes/boton-de-play (2).png")
        self.imagen20= tk.PhotoImage(file="imagenes/pausa (2).png")
        self.imagen21= tk.PhotoImage(file="imagenes/aplicacion-de-secuencia-de-comandos-de-acceso-directo.png")
        self.imagen22= tk.PhotoImage(file="imagenes/carpeta.png")
        self.imagen23= tk.PhotoImage(file="imagenes/nueva-carpeta.png")

        self.current_song = tk.StringVar()
        self.current_song.set("No se ha seleccionado ninguna canción")
        self.label_song = tk.Label(self.master, textvariable=self.current_song, bg="white", fg="black")
        self.label_song.place(x=20, y=30)
        self.playing = False
        self.song_length = 0
        self.current_song_index = 0
        self.current_time = tk.StringVar()
        self.total_time = tk.StringVar()
        self.song_list = []
        self.carpetas = []
        self.btn_modo = None
        self.label_time = tk.Label(self.master,background="white",image=self.imagen3)
        self.label_time.place(x=0, y=60)
        

        self.separator_black = tk.Canvas(self.master, width=3, height=700, bg="black", highlightthickness=0)
        self.separator_black.place(x=762, y=0)

        self.label_time = tk.Label(self.master, textvariable=self.current_time,background="gray")
        self.label_time.place(x=0, y=540)
        SimilarTooltip(self.label_time,"Tiempo Transcurrido")
        

        self.label_duration = tk.Label(self.master, textvariable=self.total_time,background="pink",)
        self.label_duration.place(x=730, y=540)
        SimilarTooltip(self.label_duration,"Duracion total de la cancion")

        self.progress_bar = ttk.Progressbar(self.master, orient="horizontal", length=800, mode="determinate")
        self.progress_bar.place(x=30, y=540,width=704)
        

        self.btn_play = tk.Button(self.master, text="▶ Reproducir/Pausa",image=self.imagen19,border=0,background="white", command=self.play_pause,cursor="hand2",state="disabled")
        self.master.bind("<Control-f>", self.atajo_reproducir_pausar)  # Atajo Ctrl + F para reproducir/pausar la canción
        self.btn_play.place(x=350, y=565)
        SimilarTooltip(self.btn_play,"Reproducir o pausar cancion")

        self.btn_stop = tk.Button(self.master, text="⏺️ Detener",image=self.imagen16,border=0,background="white", command=self.stop,cursor="hand2",state="disabled")
        self.btn_stop.place(x=150, y=565)
        SimilarTooltip(self.btn_stop,"Deterner cancion ")

        self.btn_next = tk.Button(self.master, text="⏭ Siguiente",image=self.imagen14,border=0,background="white", command=self.next_song,cursor="hand2",state="disabled")
        self.master.bind("<Control-h>", self.atajo_siguiente_cancion)  # Atajo Ctrl + H para pasar a la siguiente canción
        self.btn_next.place(x=450, y=565)
        SimilarTooltip(self.btn_next,"Pasar a la siguiente cancion")

        self.btn_prev = tk.Button(self.master, text="⏮ Anterior",image=self.imagen17,border=0,background="white", command=self.prev_song,cursor="hand2",state="disabled")
        self.master.bind("<Control-x>", self.atajo_anterior_cancion)  # Atajo Ctrl + X para volver a la canción anterior
        self.btn_prev.place(x=250, y=565)
        SimilarTooltip(self.btn_prev,"Devolverce a la cancion anterior")

        self.btn_forward = tk.Button(self.master, text="⏩10 Avanzar",image=self.imagen15,border=0,background="white", command=lambda: self.forward(10),cursor="hand2",state="disabled")
        self.btn_forward.place(x=550, y=565)
        SimilarTooltip(self.btn_forward,"Avanzar la cancion ")

        self.btn_rewind = tk.Button(self.master, text="⏪ Retroceder",image=self.imagen18,border=0,background="white", command=lambda: self.rewind(10),cursor="hand2",state="disabled")
        self.btn_rewind.place(x=50, y=565)
        SimilarTooltip(self.btn_rewind,"Retroceder la cancion")

        self.btn_load = tk.Button(self.master, text="Cargar Música", cursor="hand2", image=self.imagen11,command=self.load_songs, background="white", border=0)

        self.master.bind("<Control-j>", self.atajo_mostrar_load_song)
        self.btn_load.place(x=800, y=190)
        SimilarTooltip(self.btn_load, "Cargar la música ")



        self.btn_list = tk.Button(self.master, text="Mostrar Lista",cursor="hand2",image=self.imagen10, command=self.show_list,border=0,background="white",state="disabled")
        self.btn_list.place(x=880, y=190)
        self.master.bind("<Control-s>", self.atajo_mostrar_lista_canciones)
        SimilarTooltip(self.btn_list,"Lista de canciones")


        # Cargar la imagen y asignarla al atributo imagen
        self.imagen = tk.PhotoImage(file="imagenes/whatsapp.png")
        self.imagen2 = tk.PhotoImage(file="imagenes/compartir.png")

        # Crear el Menubutton y asociar la imagen
        menubutton = tk.Menubutton(self.master, text="Compartir",cursor="hand2", image=self.imagen2, border=0, relief=tk.RAISED,background="white")
        menubutton.place(x=1135, y=32)
        self.master.bind("<Control-b>", self.atajo_compartir)
        SimilarTooltip(menubutton,"Compartir")

        # Crear un menú secundario para la cascada
        submenu = Menu(menubutton, tearoff=0)
        menubutton.config(menu=submenu)

        # Agregar un comando a la cascada
        submenu.add_command(label="WhatsApp", image=self.imagen, compound="left", background="white",command=self.compartir_whatsapp)

        self.search_entry = tk.Entry(self.master,state="disabled")
        self.search_entry.insert(0, "Busca tu canción")  # Texto inicial en la caja de búsqueda
        self.search_entry.place(x=950, y=90,width=180,height=28)
        self.search_entry.bind("<FocusIn>", lambda event: self.on_entry_focus())
        SimilarTooltip(self.search_entry,"Buscar cancion")

        self.btn_search = tk.Button(self.master, text="Buscar",cursor="hand2",state="disabled", command=self.search_song,image=self.imagen9,border=0,background="white")
        self.btn_search.place(x=1150, y=90)
        SimilarTooltip(self.btn_search,"Buscar la cancion")

        self.boton_bluetooth = Button(self.master, text="Bluetooth",cursor="hand2", background="white",image=self.imagen5, borderwidth=0,command=self.conectar_bluetooth)
        self.boton_bluetooth.place(x=1100, y=55, anchor="center")
        SimilarTooltip(self.boton_bluetooth,"bluetooth")

        self.btn_ajustes = tk.Button(self.master, text="Ajustes",cursor="hand2",image=self.imagen6, command=self.mostrar_ajustes,background="white",border=0)
        self.master.bind("<Control-a>", self.atajo_mostrar_ajustes)  # Atajo Ctrl + Y para mostrar ajustes
        self.btn_ajustes.place(x=910, y=32)
        SimilarTooltip(self.btn_ajustes,"Ajustes")
        
        self.btn_ayuda = tk.Button(self.master, text="Ayuda",image=self.imagen7,cursor="hand2", command=self.mostrar_ayuda,border=0,background="white")
        self.master.bind("<Control-space>", self.atajo_mostrar_ayuda)  # Atajo Ctrl + Espacio para mostrar ayuda
        self.btn_ayuda.place(x=970, y=32)
        SimilarTooltip(self.btn_ayuda,"Ayuda")

        self.btn_version = tk.Button(self.master, text="version",image=self.imagen8,cursor="hand2", command=self.mostrar_version,border=0,background="white")
        self.btn_version.place(x=1030, y=32)
        self.master.bind("<Control-p>", self.atajo_version)
        SimilarTooltip(self.btn_version,"Novedades y version")


        self.btn_crear_carpeta = tk.Button(self.master, text="Crear Carpeta",state="disabled",cursor="hand2",image=self.imagen23,border=0,background="white", command=self.abrir_ventana_crear_carpeta)
        self.btn_crear_carpeta.place(x=865, y=88)
        self.master.bind("<Control-e>", self.atajo_crearCarpeta)

        self.btn_atajos = tk.Button(self.master, text="Atajos",image=self.imagen21,border=0,background="white", cursor="hand2", command=self.similar_atajos.mostrar_atajos)
        self.btn_atajos.place(x=800, y=85)
        
        SimilarTooltip(self.btn_atajos, "Ver atajos de teclado")
    

        


        self.label_time1 = tk.Label(self.master,text="Temas",background="white")
        self.label_time1.place(x=1050, y=150)


        self.label_time1 = tk.Label(self.master,text="Mis carpetas",background="white")
        self.label_time1.place(x=800, y=250)


        self.similar_musica = SimilarMusica

        self.frame_carpetas = tk.Frame(self.master, bg="white")
        self.frame_carpetas.place(x=800, y=270)  # Aj

        self.favoritos = []
         
        self.carpetas = []

        self.master.mainloop()

   

    def agregar_a_favoritos(self, song):
        self.favoritos.append(song)


    def abrir_ventana_crear_carpeta(self):
        # Crear y mostrar la ventana emergente de creación de carpeta
        self.ventana_crear_carpeta = tk.Toplevel(self.master)
        self.app_crear_carpeta = VentanaCrearCarpeta(self.ventana_crear_carpeta, self)

    def actualizar_lista_carpetas(self, nombre_carpeta):
        # Agregar la carpeta recién creada a la lista de carpetas
        self.carpetas.append(nombre_carpeta)

        # Crear un botón y un label para representar la nueva carpeta
        self.btn_nueva_carpeta = tk.Button(self.frame_carpetas, text=nombre_carpeta, image=self.imagen22, background="white", border=0, cursor="hand2",command=self.show_list)
        self.btn_nueva_carpeta.place(x=1050, y=220)  # Nuevas coordenadas
        self.btn_nueva_carpeta.bind("<Button-3>", self.mostrar_menu_contextual)
        self.btn_nueva_carpeta.pack(side=tk.TOP, pady=5)

        self.label_nombre_carpeta = tk.Label(self.frame_carpetas, text=nombre_carpeta, background="white")
        self.label_nombre_carpeta.place(x=1050, y=190)  # Nuevas coordenadas
        self.label_nombre_carpeta.pack(side=tk.TOP, pady=5)


    def atajo_mostrar_ajustes(self,event):
        self.mostrar_ajustes()


    def atajo_reproducir_pausar(self,event):
        self.play_pause()

    def atajo_siguiente_cancion(self,event):
        self.next_song()

    def atajo_anterior_cancion(self,event):
        self.prev_song()

    def atajo_mostrar_ayuda(self,event):
        self.mostrar_ayuda()

    def atajo_mostrar_load_song(self,event):
        self.load_songs()

    def atajo_mostrar_lista_canciones(self,event):
        self.show_list()

    def atajo_compartir(self,event):
        self.compartir_whatsapp()

    def atajo_version(self,event):
        self.mostrar_version()

    def atajo_crearCarpeta(self,event):
        self.abrir_ventana_crear_carpeta()

    
    
        
    def mostrar_menu_contextual(self, event):
    
        # Crear el menú contextual
        menu_contextual = tk.Menu(self.master, tearoff=0)
        menu_contextual.add_command(label="Editar Nombre", command=self.editar_nombre)
        menu_contextual.add_command(label="Eliminar Carpeta", command=self.eliminar_carpeta)


        # Mostrar el menú en la posición del evento
        menu_contextual.post(event.x_root, event.y_root)

    def editar_nombre(self):
        try:
            # Mostrar un cuadro de diálogo para que el usuario ingrese el nuevo nombre de la carpeta
            nuevo_nombre = askstring("Editar Nombre", "Ingrese el nuevo nombre de la carpeta:")

            if nuevo_nombre:
                # Actualizar el texto del botón y el label con el nuevo nombre
                self.btn_nueva_carpeta.config(text=nuevo_nombre)
                self.label_nombre_carpeta.config(text=nuevo_nombre)

                # Actualizar el nombre de la carpeta en la lista de carpetas
                indice = self.carpetas.index(self.label_nombre_carpeta)
                self.carpetas[indice] = nuevo_nombre
        
        except Exception as e:
            # Manejar otras excepciones no previstas
            messagebox.showerror("Error", str(e))

    def eliminar_carpeta(self):
        try:
            # Eliminar visualmente el botón, la imagen y el label de la carpeta seleccionada
            self.btn_nueva_carpeta.destroy()
            self.label_nombre_carpeta.destroy()

            # Eliminar la carpeta de la lista de carpetas
            if self.label_nombre_carpeta in self.carpetas:
                self.carpetas.remove(self.label_nombre_carpeta)
        except Exception as e:
            # Manejar cualquier excepción que ocurra durante el proceso
            messagebox.showerror("Error", str(e))
    
    

    def play_pause(self):
        self.similar_musica.play_pause(self)


    def prev_song(self):
        self.similar_musica.prev_song(self)


    def next_song(self):
        self.similar_musica.next_song(self)

    def stop(self):
        pygame.mixer.music.stop()
        self.playing = False



    def forward(self, seconds_to_advance):
        current_pos = pygame.mixer.music.get_pos() / 1000
        new_pos = current_pos + seconds_to_advance
        if new_pos > self.song_length:
            new_pos = self.song_length
        pygame.mixer.music.set_pos(new_pos)

    def rewind(self, seconds):
        current_pos = pygame.mixer.music.get_pos() / 1000
        new_pos = current_pos - seconds
        if new_pos < 0:
            new_pos = 0
        pygame.mixer.music.set_pos(new_pos)


    def toggle_modo_oscuro(self):
        self.master.configure(bg="black")
        self.label_song.config(bg="black", fg="white")
        self.label_song1.config(bg="black", fg="white")
        self.label_time.config(bg="white", fg="black")
        self.label_time1.config(bg="black", fg="white")
        self.label_duration.config(bg="white", fg="black")
        self.canvas.config(bg="black")

        # Cambiar el fondo del botón de ajustes a negro
        self.btn_search.configure(bg="black", fg="white")
        self.search_entry.configure(bg="gray",fg="black")
        self.btn_modo_oscuro.configure(bg="black", fg="white")
        self.btn_modo_agua.configure(bg="black", fg="white")
        self.btn_list.configure(bg="black", fg="white")
        self.btn_load.configure(bg="black", fg="white")
        self.btn_atajos.configure(bg="black", fg="white")
        self.btn_crear_carpeta.configure(bg="black", fg="white")
        self.btn_nueva_carpeta.configure(bg="black", fg="white")
        self.frame_carpetas.configure(bg="black")
        self.label_nombre_carpeta.config(bg="black",fg="white")


    def toggle_modo_agua(self):
        
        self.master.configure(bg="white")
        self.label_song.config(bg="white", fg="black")
        self.label_song1.config(bg="white", fg="black")
        self.label_time1.config(bg="white", fg="black")
        self.label_time.config(bg="lightblue", fg="black")
        self.label_duration.config(bg="lightblue", fg="black")
        self.canvas.config(bg="white")
        self.btn_search.configure(bg="white", fg="white")
        self.search_entry.configure(bg="white",fg="black")
        self.btn_modo_oscuro.configure(bg="white", fg="white")
        self.btn_modo_agua.configure(bg="white", fg="white")
        self.btn_list.configure(bg="white", fg="white")
        self.btn_load.configure(bg="white", fg="white")
        self.btn_atajos.configure(bg="white", fg="white")
        self.btn_crear_carpeta.configure(bg="white", fg="white")
        self.btn_nueva_carpeta.configure(bg="white", fg="white")
        self.frame_carpetas.configure(bg="white")
        self.label_nombre_carpeta.config(bg="white",fg="black")
        
    def mostrar_ajustes(self):
       
        # Agregar botones para cambiar el modo directamente en MusicPlayer
        self.btn_modo_oscuro = tk.Button(self.master,cursor="hand2", text="noche",border=0,background="white", image=self.imagen13,command=self.toggle_modo_oscuro)
        self.btn_modo_oscuro.place(x=1000, y=190)
        SimilarTooltip(self.btn_modo_oscuro,"Modo negro")

        self.btn_modo_agua = tk.Button(self.master, cursor="hand2",text="claro",image=self.imagen12,border=0,background="white", command=self.toggle_modo_agua)
        self.btn_modo_agua.place(x=1100, y=190)
        SimilarTooltip(self.btn_modo_agua,"Modo blanco")

    def mostrar_ayuda(self):
        self.ventana_ayuda = similarayuida(self.master)

    def mostrar_version(self):
        self.ventana = similarversion(self.master)

    def compartir_whatsapp(self):
        self.compartir.set_cancion_actual(self.current_song.get())
        self.compartir.compartir_whatsapp()
   

    def conectar_bluetooth(self):
        # Abrir el panel de configuración de Bluetooth
        self.manager.abrir_panel_bluetooth()

        # Dirección MAC del dispositivo Bluetooth al que deseamos conectarnos
        direccion_mac_dispositivo = "60-18-95-14-C5-F2"  # Reemplaza con la dirección MAC de tu dispositivo

        # Conectar el dispositivo Bluetooth
        self.manager.conectar_dispositivo(direccion_mac_dispositivo)

    def on_entry_focus(self):
        self.search_entry.delete(0, tk.END)  # Eliminar el texto inicial cuando se hace clic en la caja de búsqueda


    def load_songs(self):
        music_dir = filedialog.askdirectory()
        if music_dir:
            self.song_list = [os.path.join(music_dir, filename) for filename in os.listdir(music_dir) if
                              filename.endswith(".mp3")]
            if self.song_list:
                # Habilitar los botones después de cargar las canciones
                self.enable_buttons()
                # Reproducir la primera canción
                self.play_selected_song(self.song_list[self.current_song_index])
        

    def enable_buttons(self):
        # Habilitar todos los botones después de cargar las canciones
        self.btn_play.config(state=tk.NORMAL)
        self.btn_stop.config(state=tk.NORMAL)
        self.btn_list.config(state=tk.NORMAL)
        self.btn_forward.config(state=tk.NORMAL)
        self.btn_next.config(state=tk.NORMAL)
        self.btn_prev.config(state=tk.NORMAL)
        self.btn_search.config(state=tk.NORMAL)
        self.btn_rewind.config(state=tk.NORMAL)
        self.search_entry.config(state=tk.NORMAL)
        self.btn_crear_carpeta.config(state=tk.NORMAL)

    def show_list(self):
        self.similar_lista = SimilarLista(self.master, self.song_list, self.play_selected_song)

    def on_frame_configure(self, canvas):
        canvas.configure(scrollregion=canvas.bbox("all"))

    def play_selected_song(self, song):
        pygame.mixer.music.load(song)
        pygame.mixer.music.play()
        self.current_song.set(os.path.basename(song))
        self.song_length = pygame.mixer.Sound(song).get_length()
        self.playing = True
        self.update_progress()
        self.agregar_a_favoritos(song)

    def search_song(self):
        query = self.search_entry.get().lower()
        filtered_songs = [song for song in self.song_list if query in song.lower()]
        self.show_list_with_filtered(filtered_songs)

    def show_list_with_filtered(self, filtered_songs):
        self.similar_busqueda = SimilarBusqueda(self.master, filtered_songs, self.play_selected_song)
    

    def update_progress(self):
        if pygame.mixer.music.get_busy():
            current_pos = pygame.mixer.music.get_pos() / 1000
            self.progress_bar.config(maximum=self.song_length, value=current_pos)
            self.current_time.set(self.format_time(current_pos))
            self.total_time.set(self.format_time(self.song_length))
            self.master.after(1000, self.update_progress)
        else:
            self.progress_bar.config(value=0)
            self.current_time.set("00:00")
            self.total_time.set("00:00")

    def format_time(self, seconds):
        minutes, seconds = divmod(seconds, 60)
        return f"{int(minutes):02d}:{int(seconds):02d}"
    



