import http.server
import socketserver

PORT = 8000  # Puerto en el que se ejecutará el servidor

class MiHandler(http.server.SimpleHTTPRequestHandler):
    # Sobreescribir el método para cambiar el directorio raíz del servidor
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory='ruta_a_tu_directorio', **kwargs)

# Crear el servidor con nuestro manejador personalizado
with socketserver.TCPServer(("", PORT), MiHandler) as httpd:
    print("Servidor HTTP en el puerto", PORT)
    # Iniciar el servidor y mantenerlo en funcionamiento
    httpd.serve_forever()
