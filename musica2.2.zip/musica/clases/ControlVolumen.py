import tkinter as tk

class ControlVolumen:
    def __init__(self, ventana, pygame_mixer):
        self.ventana = ventana
        self.pygame_mixer = pygame_mixer

        # Crear una barra de desplazamiento vertical para el volumen
        self.slider_volumen = tk.Scale(self.ventana, from_=0, to=100, orient=tk.VERTICAL, label="", command=self.cambiar_volumen)
        self.slider_volumen.set(50)  # Establecer el volumen inicial al 50% de 300

        # Configurar el estilo del botón de volumen
        self.slider_volumen.config(bg="white", troughcolor="lightgray", highlightbackground="black", bd=2, relief=tk.RIDGE)

        # Posicionar el botón de volumen en la ventana
        self.slider_volumen.place(x=728, y=150)

    def cambiar_volumen(self, valor):
        # Convertir el valor del control deslizante al rango 0-1 (normalizar)
        volumen_normalizado = float(valor) / 100
        # Ajustar el volumen para que sea más alto
        volumen_ajustado = volumen_normalizado * 1.5  # Multiplicar por un factor (por ejemplo, 1.5) para que suene más alto
        # Establecer el volumen de pygame
        self.pygame_mixer.music.set_volume(volumen_ajustado)

