

from PyQt5.QtCore import QTimer
import speedtest



class Wifi:
    def __init__(self,ventana):
        self.ventana= ventana
        self.speedtester = speedtest.Speedtest()
        self.download_speed = 0
        self.upload_speed = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_speed)
        self.timer.start(5000)  # Actualizar cada 5 segundos

    def update_speed(self):
        self.download_speed = self.speedtester.download() / 1_000_000
        self.upload_speed = self.speedtester.upload() / 1_000_000



    




            